// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signing_session_recipient_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SigningSessionRecipientImpl _$$SigningSessionRecipientImplFromJson(
  Map<String, dynamic> json,
) => _$SigningSessionRecipientImpl(
  sessionId: json['sessionId'] as String,
  recipientId: json['recipientId'] as String,
);

Map<String, dynamic> _$$SigningSessionRecipientImplToJson(
  _$SigningSessionRecipientImpl instance,
) => <String, dynamic>{
  'sessionId': instance.sessionId,
  'recipientId': instance.recipientId,
};
