import 'dart:io';

import 'package:bsign/view/pages/document/doc_view.dart';
import 'package:flutter/material.dart';
import 'package:bsign/models/document/document_model.dart';
import 'package:bsign/services/document_service.dart';

class DocumentProvider with ChangeNotifier {
  final DocumentService _service = DocumentService();

  List<Document> _documents = [];
  List<Document> get documents => _documents;

  bool _isLoading = false;
  bool get isLoading => _isLoading;
  Document? _currentDocument;
  bool _isUploading = false;
  Document? get currentDocument => _currentDocument;
  bool get isUploading => _isUploading;


Widget getDocumentPage(Document doc) {
  return DocumentViewScreen(
    documentId: doc.id!,
    filePath: doc.file_url, // Direct URL from Supabase
    totalPages: doc.pages,
  );
}

  Future<void> loadDocuments(String ownerId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _documents = await _service.fetchPendingDocuments(ownerId);
    } catch (e) {
      debugPrint('Error loading documents: $e');
    }

    _isLoading = false;
    notifyListeners();
  }

  Future<void> loadUserDocuments(String userId) async {
    _isLoading = true;
    notifyListeners();

    try {
      _documents = await _service.fetchUserDocuments(userId);
    } catch (e) {
      debugPrint('Error loading user documents: $e');
    }

    _isLoading = false;
    notifyListeners();
  }
  Future<void> createDocument({
    required File file,
    required String userId,
    required String type,
    required Document doc,
  }) async {
    try {
      _isUploading = true;
      notifyListeners();

      _currentDocument = await _service.createDocument(
        file: file,
        userId: userId,
        type: type,
        doc: doc,
      );
      
      // Refresh documents list
      await loadDocuments(userId);
    } catch (e) {
      debugPrint('Error uploading file: $e');
      rethrow;
    } finally {
      _isUploading = false;
      notifyListeners();
    }
  }

  Future<void> refreshDocuments(String userId) async {
    await loadDocuments(userId);
  }
}
