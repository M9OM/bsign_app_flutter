
class Apis {
  static const String supabaseUrl = 'https://ytnppambahdtqsiiguio.supabase.co';
  static const String supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl0bnBwYW1iYWhkdHFzaWlndWlvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc3MjAyOTYsImV4cCI6MjA2MzI5NjI5Nn0.I5n2vW-anI6AJutw3N6oOYXrVQ6iGg5aF9y8CRH9G1o';


}
